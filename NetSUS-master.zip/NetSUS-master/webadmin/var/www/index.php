<?php

header('Location: /webadmin');

?>
